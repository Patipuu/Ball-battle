using System.Collections.Generic;
using BallBattle.Sim;
using BallBattle.Sim.Traits;
using BallBattle.Sim.Weapons;
using UnityEngine;

namespace BallBattle.View
{
    /// <summary>
    /// Turns sim events into feel: hit flash, damage numbers, pixel sparks, integer-pixel screen shake,
    /// and a short slow-motion of the effects on a knockout. View-only: never touches the sim.
    /// Lives next to ArenaView and listens to its events.
    /// </summary>
    [RequireComponent(typeof(ArenaView))]
    public sealed class FxView : MonoBehaviour
    {
        /// <summary>Clips for AudioDirector (BB-03 moved all sound playing there; FxView only draws).</summary>
        public SfxLibrary Sfx;

        const float FlashSeconds = 0.06f;
        const float KoSlowMoSeconds = 0.5f;
        const float KoSlowMoScale = 0.3f;
        static readonly Color32 StatusPoison = new Color32(96, 255, 64, 255);
        static readonly Color32 StatusHeal = new Color32(80, 255, 160, 255);
        /// <summary>Reflect damage (Aegis, Thorns, Spiky): numbers, flash and particles.</summary>
        public static readonly Color32 ReflectColor = new Color32(255, 90, 200, 255);
        const float ReflectFlightSeconds = 0.18f;
        /// <summary>Reflect damage: 1 px edge flash on the ball hit back, and a 2x number.</summary>
        public const float ReflectFlashSeconds = 0.12f;
        public const int ReflectNumberScale = 2;
        /// <summary>Thorns motes are spikes 2 px thick and 5 px long, flying tip first from A to B.</summary>
        public const int ThornSpikeThickness = 2;
        public const int ThornSpikeLength = 5;

        /// <summary>
        /// Offsets (tip first, going back along <paramref name="dir"/>) of the 2x2 particles that draw one Thorns spike:
        /// 4 squares of 2 px stepped 1 px apart = 5 px long, 2 px thick.
        /// </summary>
        public static Vector2[] ThornSpikeOffsets(Vector2 dir)
        {
            var d = dir.sqrMagnitude > 0.0001f ? dir.normalized : Vector2.up;
            var n = ThornSpikeLength - ThornSpikeThickness + 1;
            var offsets = new Vector2[n];
            for (var j = 0; j < n; j++) offsets[j] = -d * j;
            return offsets;
        }

        ArenaView arena;
        PixelParticles particles;
        DamagePopups popups;
        ScreenShake shake;
        float slowMoRemaining;

        // Reflect damage is shown once its whole tick is known (Parry comes after the Damage it caused).
        readonly List<SimEvent> pendingTick = new List<SimEvent>();
        readonly List<ReflectFx> reflects = new List<ReflectFx>();
        readonly ReflectSourceClassifier classifier = new ReflectSourceClassifier();
        readonly SimOwners owners = new SimOwners();

        // Built in Awake (not Start) so effects work from the very first tick, whatever order the Starts run in.
        void Awake()
        {
            arena = GetComponent<ArenaView>();
            particles = PixelParticles.Create(transform, arena.Art.Pixel, 96);
            popups = DamagePopups.Create(transform, arena.Art.Font, 8);
            var cam = Camera.main;
            if (cam != null) shake = new ScreenShake(cam.transform);
        }

        void OnEnable()
        {
            if (arena == null) arena = GetComponent<ArenaView>();
            arena.SimEventRaised += OnSimEvent;
            arena.MatchStarted += OnMatchStarted;
        }

        void OnDisable()
        {
            arena.SimEventRaised -= OnSimEvent;
            arena.MatchStarted -= OnMatchStarted;
            pendingTick.Clear();
            shake?.Stop();
        }

        void OnMatchStarted()
        {
            particles?.Clear();
            popups?.Clear();
            shake?.Stop();
            slowMoRemaining = 0f;
            pendingTick.Clear();
            secondWindShown[0] = secondWindShown[1] = false;
            secondWindTick[0] = secondWindTick[1] = -1;
            foreach (var r in rings) { r.Renderer.enabled = false; r.Age = RingPulseSeconds; }
        }

        /// <summary>Damage/heal number kept inside the current (possibly shrunk) arena.</summary>
        void ShowPopup(Vector2 at, float value, Color32 color, int scale = 0)
        {
            if (arena.Sim != null) popups.Show(at, value, color, arena.Sim.Arena, scale);
            else popups.Show(at, value, color, scale);
        }

        // ---- Second Wind ----

        /// <summary>Second Wind heal number and ring: pale turquoise (not the lime of poison 96,255,64).</summary>
        public static readonly Color32 SecondWindColor = new Color32(140, 240, 220, 255);
        /// <summary>"2ND WIND" caption under the number (the trait's badge color).</summary>
        public static readonly Color32 SecondWindLabelColor = new Color32(60, 150, 170, 255);
        public const string SecondWindLabel = "2ND WIND";
        public const float RingPulseSeconds = 0.3f;
        const float RingPulseGrow = 0.8f;   // the ring ends at 1.8x the ball size

        readonly bool[] secondWindShown = new bool[2];

        sealed class RingPulse
        {
            public SpriteRenderer Renderer;
            public int Ball;
            public float Age = RingPulseSeconds;
        }

        readonly List<RingPulse> rings = new List<RingPulse>();

        readonly int[] secondWindTick = { -1, -1 };

        void ShowSecondWind(SimEvent e)
        {
            if (e.A < 0 || e.A >= secondWindShown.Length || secondWindShown[e.A]) return;
            secondWindShown[e.A] = true;
            secondWindTick[e.A] = e.Tick;
            var ball = arena.Sim.Balls[e.A];
            var at = V(ball.Pos) + new Vector2(0f, ball.Radius + 4f);
            popups.ShowLabelled(at, "+" + popups.Format(e.Value), SecondWindColor, 2, SecondWindLabel, SecondWindLabelColor, arena.Sim.Arena);
            StartRing(e.A);
            arena.Badges?.SetSpent(e.A, SecondWindTrait.TraitId, true);
        }

        void StartRing(int ballIndex)
        {
            RingPulse r = null;
            foreach (var x in rings) if (x.Age >= RingPulseSeconds) { r = x; break; }
            if (r == null)
            {
                var go = new GameObject("SecondWindRing");
                go.transform.SetParent(transform, false);
                var sr = go.AddComponent<SpriteRenderer>();
                sr.sprite = ProceduralSprites.BallOutlineThin;
                sr.sortingOrder = PixelParticles.Order + 1;
                r = new RingPulse { Renderer = sr };
                rings.Add(r);
            }
            r.Ball = ballIndex;
            r.Age = 0f;
            r.Renderer.enabled = true;
            PlaceRing(r);
        }

        void TickRings(float dt)
        {
            foreach (var r in rings)
            {
                if (r.Age >= RingPulseSeconds) continue;
                r.Age += dt;
                if (r.Age >= RingPulseSeconds) { r.Renderer.enabled = false; continue; }
                PlaceRing(r);
            }
        }

        void PlaceRing(RingPulse r)
        {
            var view = arena.GetBallView(r.Ball);
            var t = Mathf.Clamp01(r.Age / RingPulseSeconds);
            var baseScale = view != null ? view.Scale : 1f;
            var s = baseScale * (1f + RingPulseGrow * t);
            if (view != null) r.Renderer.transform.localPosition = view.transform.localPosition;
            r.Renderer.transform.localScale = new Vector3(s, s, 1f);
            var c = SecondWindColor;
            c.a = (byte)(255f * (1f - t));
            r.Renderer.color = c;
        }

        /// <summary>Second Wind ring pulses showing now (tests).</summary>
        public int ActiveRingPulses
        {
            get
            {
                var n = 0;
                foreach (var r in rings) if (r.Age < RingPulseSeconds && r.Renderer.enabled) n++;
                return n;
            }
        }

        /// <summary>Damage numbers (tests).</summary>
        public DamagePopups Popups => popups;

        Color32 BallColor(int index) => Palette.Look(arena.Sim.Balls[index].Weapon.Id).Body;

        static Vector2 V(Vec2 p) => new Vector2(p.X, p.Y);

        void OnSimEvent(SimEvent e)
        {
            if (particles == null) return;   // events before Start (first frame) are ignored
            if (pendingTick.Count > 0 && pendingTick[0].Tick != e.Tick) FlushReflects();
            pendingTick.Add(e);
            switch (e.Type)
            {
                case SimEventType.Hit:
                {
                    var target = arena.Sim.Balls[e.B];
                    arena.GetBallView(e.B)?.Flash(FlashSeconds);
                    particles.Burst(V(e.Point), e.Value >= 5f ? 7 : 5, BallColor(e.A), 50f, 110f, 0.35f, e.Value >= 5f ? 2 : 1);
                    ShowPopup(V(target.Pos) + new Vector2(0f, target.Radius + 4f), e.Value, Palette.Text);
                    shake?.Add(Mathf.Clamp(1f + e.Value / 6f, 1f, ScreenShake.MaxAmplitude), 0.15f);
                    break;
                }
                case SimEventType.Parry:
                    particles.Burst(V(e.Point), 6, Palette.Text, 80f, 150f, 0.25f);
                    particles.Burst(V(e.Point), 3, Palette.WallWarning, 60f, 120f, 0.3f);
                    shake?.Add(1f, 0.08f);
                    break;
                case SimEventType.ProjectileFired:
                    particles.Burst(V(e.Point), 2, BallColor(e.A), 20f, 50f, 0.15f);
                    break;
                case SimEventType.ProjectileHit:
                    if (e.Value > 0f)
                    {
                        var hurt = arena.Sim.Balls[e.B];
                        arena.GetBallView(e.B)?.Flash(FlashSeconds);
                        particles.Burst(V(e.Point), 4, BallColor(e.A), 40f, 90f, 0.25f);
                        ShowPopup(V(hurt.Pos) + new Vector2(0f, hurt.Radius + 4f), e.Value, Palette.Text);
                    }
                    break;
                case SimEventType.ProjectileDeflected:
                    particles.Burst(V(e.Point), 4, Palette.Text, 60f, 120f, 0.2f);
                    break;
                case SimEventType.StatusTick:
                {
                    var sick = arena.Sim.Balls[e.A];
                    particles.Burst(V(sick.Pos), 3, StatusPoison, 20f, 60f, 0.3f);
                    ShowPopup(V(sick.Pos) + new Vector2(0f, sick.Radius + 4f), e.Value, StatusPoison);
                    break;
                }
                case SimEventType.ShieldBlocked:
                    if (e.A == arena.BossBall) arena.PlayBossGlow();   // Shell King glows 1 s when its shield takes a hit
                    particles.Burst(V(e.Point), 6, Palette.Text, 60f, 130f, 0.3f);
                    break;
                case SimEventType.Heal:
                    if (e.A >= 0 && e.A < secondWindTick.Length && secondWindTick[e.A] == e.Tick) break;
                    if (e.Value >= 0.5f)
                    {
                        var healed = arena.Sim.Balls[e.A];
                        ShowPopup(V(healed.Pos) + new Vector2(0f, healed.Radius + 4f), e.Value, StatusHeal);
                        particles.Burst(V(healed.Pos), 3, StatusHeal, 15f, 50f, 0.4f);
                    }
                    break;
                case SimEventType.TraitTriggered:
                    if (e.TraitId == SecondWindTrait.TraitId) ShowSecondWind(e);
                    break;
                case SimEventType.ObstacleHit:
                    if (e.Value > 0f)
                    {
                        particles.Burst(V(e.Point), 4, Palette.Hot, 40f, 100f, 0.25f);
                        ShowPopup(V(e.Point), e.Value, Palette.Hot);
                    }
                    break;
                case SimEventType.WallBounce:
                    if (e.Value > 0f) ShowPopup(V(arena.Sim.Balls[e.A].Pos), e.Value, Palette.Hot);
                    break;
                case SimEventType.BallBounce:
                    break;
                case SimEventType.Death:
                    particles.Burst(V(e.Point), 18, BallColor(e.A), 40f, 160f, 0.8f, 2);
                    particles.Burst(V(e.Point), 10, Palette.Text, 60f, 140f, 0.5f);
                    shake?.Add(ScreenShake.MaxAmplitude, 0.4f);
                    slowMoRemaining = KoSlowMoSeconds;
                    break;
                case SimEventType.Damage:
                    break;   // Reflect damage: shown by FlushReflects once the tick is complete
            }
        }

        void Update()
        {
            if (particles == null) return;
            var dt = Time.deltaTime;
            var fxDt = dt;
            if (slowMoRemaining > 0f)
            {
                slowMoRemaining -= dt;
                fxDt *= KoSlowMoScale;
            }
            FlushReflects();
            particles.Tick(fxDt);
            TickRings(fxDt);
            popups.SetBounds(arena.Sim != null ? arena.Sim.Arena : (ArenaRect?)null);
            popups.Tick(fxDt);
            shake?.Tick(dt);
        }

        /// <summary>Classify and show every Reflect damage of the buffered tick(s), then forget them.</summary>
        void FlushReflects()
        {
            if (pendingTick.Count == 0) return;
            reflects.Clear();
            var sim = arena != null ? arena.Sim : null;
            if (sim != null && particles != null)
            {
                owners.Sim = sim;
                classifier.Classify(pendingTick, owners, reflects);
            }
            pendingTick.Clear();
            for (var i = 0; i < reflects.Count; i++) ShowReflect(sim, reflects[i]);
            reflects.Clear();
        }

        void ShowReflect(MatchSim sim, in ReflectFx r)
        {
            var d = r.Damage;
            if (d.A >= sim.Balls.Count || d.B >= sim.Balls.Count) return;
            var src = sim.Balls[d.A];
            var hurt = sim.Balls[d.B];

            // The ball the damage came BACK to (d.B) shows it: 1 px magenta edge, body keeps its weapon color.
            arena.GetBallView(d.B)?.FlashEdge(ReflectFlashSeconds, ReflectColor);
            ShowPopup(V(hurt.Pos) + new Vector2(0f, hurt.Radius + 4f), d.Value, ReflectColor, ReflectNumberScale);

            // 3-4 magenta motes fly from the reflecting ball to the one it hurts (spikes for Thorns).
            var to = V(hurt.Pos);
            var count = d.Value >= 2f ? 4 : 3;
            for (var k = 0; k < count; k++)
            {
                var start = V(src.Pos) + Random.insideUnitCircle * (src.Radius * 0.6f);
                var flight = ReflectFlightSeconds * Random.Range(0.85f, 1.15f);
                var travel = to - start;
                var vel = travel / flight;
                if (r.Source == ReflectSource.Thorns)
                {
                    var dir = travel.sqrMagnitude > 0.01f ? travel.normalized : Vector2.up;
                    foreach (var o in ThornSpikeOffsets(dir)) particles.Emit(start + o, vel, ReflectColor, flight, ThornSpikeThickness);   // 2x5 px spike, tip first
                }
                else particles.Emit(start, vel, ReflectColor, flight);
            }

            var at = V(r.Point);
            switch (r.Source)
            {
                case ReflectSource.Spiky:   // ring bursting at the bump
                    for (var k = 0; k < 8; k++)
                    {
                        var a = k * Mathf.PI / 4f;
                        particles.Emit(at, new Vector2(Mathf.Cos(a), Mathf.Sin(a)) * 70f, ReflectColor, 0.25f);
                    }
                    break;
                case ReflectSource.Aegis:   // streak running along the shield
                    if (src.Weapon.HasBlade)
                    {
                        var s0 = V(src.BladeStart);
                        var s1 = V(src.BladeEnd);
                        var along = s1 - s0;
                        var speed = along.sqrMagnitude > 0.01f ? along.normalized * 90f : Vector2.zero;
                        for (var k = 0; k < 6; k++)
                            particles.Emit(Vector2.Lerp(s0, s1, k / 5f), speed, ReflectColor, 0.08f + 0.03f * k);
                    }
                    else particles.Burst(at, 4, ReflectColor, 40f, 90f, 0.2f);
                    break;
                default:   // Thorns
                    particles.Burst(at, 3, ReflectColor, 40f, 90f, 0.2f);
                    break;
            }
        }

        /// <summary>What each ball of the live match owns, for the reflect classifier.</summary>
        sealed class SimOwners : ReflectSourceClassifier.IOwners
        {
            public MatchSim Sim;

            BallState Ball(int i) => Sim != null && i >= 0 && i < Sim.Balls.Count ? Sim.Balls[i] : null;

            public bool UsesAegis(int ball) => Ball(ball)?.Weapon is AegisRule;
            public bool HasThorns(int ball) => Has(Ball(ball), ThornsTrait.TraitId);
            public bool HasSpiky(int ball) => Has(Ball(ball), SpikyTrait.TraitId);
            public Vec2 Center(int ball) => Ball(ball)?.Pos ?? Vec2.Zero;

            static bool Has(BallState b, string traitId)
            {
                if (b?.Traits == null) return false;
                foreach (var t in b.Traits)
                    if (t != null && t.Id == traitId) return true;
                return false;
            }
        }
    }
}
