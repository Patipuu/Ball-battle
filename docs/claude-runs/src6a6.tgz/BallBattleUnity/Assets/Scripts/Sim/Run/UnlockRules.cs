using System;
using System.Collections.Generic;
using BallBattle.Sim.Traits;
using BallBattle.Sim.Weapons;

namespace BallBattle.Sim.Run
{
    /// <summary>Long-term progress (saved). Unlocks are derived from achievements, so the table can change later.</summary>
    [Serializable]
    public sealed class ProgressData
    {
        public List<string> Achievements = new List<string>();
        public int RunsPlayed;
        public int RunsWon;
        /// <summary>Furthest fight reached (1-based); 0 = never played.</summary>
        public int BestFight;

        public bool Has(string achievement) => Achievements.Contains(achievement);
    }

    /// <summary>
    /// What is unlocked. Start: the 4 Step-1 weapons + 5 traits. Achievements unlock the rest.
    /// Ids not implemented yet are skipped (content arrives in later phases), so the table is stable.
    /// </summary>
    public static class UnlockRules
    {
        public const string Boss1 = "boss1", Boss2 = "boss2", Boss3 = "boss3", Win1 = "win1", Win3 = "win3";

        static readonly string[] StartWeapons = { "blade", "fang", "pike", "brawler" };
        static readonly string[] StartTraits = { "heavy", "vampire", "spiky", "thorns", "second-wind" };

        /// <summary>achievement → (weapons, traits) it unlocks.</summary>
        static readonly (string achievement, string[] weapons, string[] traits)[] Table =
        {
            (Boss1, new string[0], new[] { "glass-cannon" }),
            (Boss2, new[] { "volley" }, new[] { "poison-tip" }),
            (Boss3, new[] { "venom" }, new[] { "parry-master" }),
            (Win1, new[] { "aegis", "venom" }, new[] { "bubble", "parry-master" }),
            (Win3, new[] { "rig" }, new[] { "twin-blade" }),
        };

        public static List<string> Weapons(ProgressData p) => Collect(p, StartWeapons, true);
        public static List<string> Traits(ProgressData p) => Collect(p, StartTraits, false);

        static List<string> Collect(ProgressData p, string[] start, bool weapons)
        {
            var result = new List<string>();
            void Add(string id)
            {
                var exists = weapons ? WeaponExists(id) : TraitRegistry.Exists(id);
                if (exists && !result.Contains(id)) result.Add(id);
            }
            foreach (var id in start) Add(id);
            foreach (var row in Table)
                if (p.Has(row.achievement))
                    foreach (var id in weapons ? row.weapons : row.traits) Add(id);
            return result;
        }

        static bool WeaponExists(string id)
        {
            foreach (var e in WeaponRegistry.All)
                if (e.Id == id) return true;
            return false;
        }

        /// <summary>
        /// Call once after every RunState.ApplyResult: updates stats and achievements, returns the achievements
        /// earned now (the view can announce what they unlocked).
        /// </summary>
        public static List<string> Record(ProgressData p, RunState run)
        {
            var earned = new List<string>();
            void Earn(string a)
            {
                if (p.Has(a)) return;
                p.Achievements.Add(a);
                run.Achievements.Add(a);
                earned.Add(a);
            }

            var last = run.History.Count > 0 ? run.History[run.History.Count - 1] : null;
            if (last != null)
            {
                if (last.FightIndex + 1 > p.BestFight) p.BestFight = last.FightIndex + 1;
                if (last.Won && last.FightIndex == RunTuning.BossFights[0]) Earn(Boss1);
                if (last.Won && last.FightIndex == RunTuning.BossFights[1]) Earn(Boss2);
            }

            if (run.Over)
            {
                p.RunsPlayed++;
                if (run.Won)
                {
                    p.RunsWon++;
                    Earn(Win1);
                    if (p.RunsWon >= 3) Earn(Win3);
                }
            }
            return earned;
        }

        /// <summary>A saved run replaced by a new one still counts as played (and lost).</summary>
        public static void RecordAbandoned(ProgressData p) => p.RunsPlayed++;

        // ---- Next goal (BB-02): the milestones shown to the player, in order. Change milestones in GoalTable only. ----

        /// <summary>
        /// Goal rows, first not-yet-reached row = the next goal. Beating the Mimic in the last fight always wins the run,
        /// so boss2 and win1 are one goal (either achievement reaches it; its reward is both). Legacy boss3 (no longer
        /// earned) has no row: it never counts as progress and never blocks AllDone.
        /// </summary>
        public static readonly GoalRow[] GoalTable =
        {
            new GoalRow(Boss1, new[] { Boss1 }, new[] { Boss1 }, GoalProgress.FightsCleared, RunTuning.BossFights[0] + 1),
            new GoalRow(Win1, new[] { Win1, Boss2 }, new[] { Boss2, Win1 }, GoalProgress.FightsCleared, RunTuning.Fights),
            new GoalRow(Win3, new[] { Win3 }, new[] { Win3 }, GoalProgress.RunsWon, 3),
        };

        public static GoalRow GoalRowOf(string goalId)
        {
            foreach (var row in GoalTable)
                if (row.Id == goalId) return row;
            return null;
        }

        /// <summary>The next goal for this progress: plain data, no display strings.</summary>
        public static NextGoalInfo NextGoal(ProgressData p)
        {
            foreach (var row in GoalTable)
            {
                if (row.Done(p)) continue;
                var progress = row.Progress == GoalProgress.RunsWon ? p.RunsWon : FightsCleared(p);
                return new NextGoalInfo
                {
                    GoalId = row.Id,
                    RewardIds = NewRewards(row, p),
                    // Never a full bar before the goal is actually reached.
                    Current = Math.Max(0, Math.Min(progress, row.Max - 1)),
                    Max = row.Max,
                };
            }
            return new NextGoalInfo { RewardIds = new List<string>(), AllDone = true };
        }

        /// <summary>
        /// Fights cleared in the best run so far. BestFight is the furthest fight reached, 1-based, counted when that
        /// fight's result is recorded whether won or lost; so cleared = BestFight - 1 (an under-count of one only when
        /// the furthest fight recorded was a win and the run was then left).
        /// </summary>
        public static int FightsCleared(ProgressData p) => Math.Max(p.BestFight - 1, 0);

        /// <summary>Weapon/trait ids the row grants that exist in this build and are not unlocked in <paramref name="p"/> yet.</summary>
        public static List<string> NewRewards(GoalRow row, ProgressData p)
        {
            var have = Weapons(p);
            have.AddRange(Traits(p));
            var ids = new List<string>();
            foreach (var a in row.Rewards)
                foreach (var t in Table)
                {
                    if (t.achievement != a) continue;
                    foreach (var w in t.weapons)
                        if (WeaponExists(w) && !have.Contains(w) && !ids.Contains(w)) ids.Add(w);
                    foreach (var tr in t.traits)
                        if (TraitRegistry.Exists(tr) && !have.Contains(tr) && !ids.Contains(tr)) ids.Add(tr);
                }
            return ids;
        }
        /// <summary>Display names of the weapons/traits an achievement unlocks that exist in this build.</summary>
        public static List<string> UnlockedNames(string achievement)
        {
            var names = new List<string>();
            foreach (var row in Table)
            {
                if (row.achievement != achievement) continue;
                foreach (var w in row.weapons)
                    foreach (var e in WeaponRegistry.All)
                        if (e.Id == w) names.Add(e.DisplayName);
                foreach (var t in row.traits)
                    if (TraitRegistry.Exists(t)) names.Add(TraitRegistry.Get(t).DisplayName);
            }
            return names;
        }
    }

    public enum GoalProgress { FightsCleared, RunsWon }

    /// <summary>One row of <see cref="UnlockRules.GoalTable"/>.</summary>
    public sealed class GoalRow
    {
        public readonly string Id;
        /// <summary>Having any one of these achievements means the goal is reached.</summary>
        public readonly string[] DoneWhen;
        /// <summary>Achievements whose unlocks this goal grants (merged).</summary>
        public readonly string[] Rewards;
        public readonly GoalProgress Progress;
        public readonly int Max;

        public GoalRow(string id, string[] doneWhen, string[] rewards, GoalProgress progress, int max)
        {
            Id = id;
            DoneWhen = doneWhen;
            Rewards = rewards;
            Progress = progress;
            Max = max;
        }

        public bool Done(ProgressData p)
        {
            foreach (var a in DoneWhen)
                if (p.Has(a)) return true;
            return false;
        }
    }

    /// <summary>Result of <see cref="UnlockRules.NextGoal"/>: plain data, the view turns it into text.</summary>
    public struct NextGoalInfo
    {
        public string GoalId;
        public List<string> RewardIds;
        public int Current;
        public int Max;
        public bool AllDone;
    }
}
